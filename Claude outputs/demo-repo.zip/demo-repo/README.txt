Demo repo for the security commit reviewer (all credentials are FABRICATED).

  demo/                 git repo, 7 commits (branch: main)
  demo_expected.json    commit id -> expected result

Keep it LOCAL: do not push to GitHub (secret-shaped strings may be blocked by push protection).
Review a commit:  python -m reviewer --repo <path>/demo --commit <sha> --github-repo owner/security-demo
Use a test GitHub repo you own for --github-repo. Issues are only created after you type yes.
