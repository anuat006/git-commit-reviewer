def is_valid_username(name: str) -> bool:
    return name.isalnum() and 3 <= len(name) <= 20
