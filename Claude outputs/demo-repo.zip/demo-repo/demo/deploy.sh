#!/bin/sh
export GITHUB_TOKEN="ghp_aB3dE5fG7hJ9kL1mN3pQ5rS7tU9vW1xY3zA5"
echo "deploying..."
