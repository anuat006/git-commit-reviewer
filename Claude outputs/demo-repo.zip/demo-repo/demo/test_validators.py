from validators import is_valid_username


def test_username():
    assert is_valid_username("alice1")
    assert not is_valid_username("a!")
