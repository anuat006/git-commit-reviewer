DB_HOST = "db.internal"
DB_USER = "app"
DB_PASSWORD = "Sup3rS3cret!2024"
