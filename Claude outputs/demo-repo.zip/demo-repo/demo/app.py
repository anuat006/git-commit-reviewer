import os


def greet(name: str) -> str:
    return f"Hello, {name}!"


def api_url() -> str:
    return os.environ.get("API_URL", "http://localhost:8000")
